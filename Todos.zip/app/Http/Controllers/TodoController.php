<?php

namespace App\Http\Controllers;

use Session;

use App\todoModel;

use Illuminate\Http\Request;

class TodoController extends Controller
{
   public function index()
   {
   		$todos = todoModel::all();

   		return view('my-todos')->with('todos', $todos);
   } 


   public function store(Request $request)
   {
   		// dd($request->all());

   		$todoModel = new todoModel;

   		$todoModel->todo = $request->todo;

   		$todoModel->save();

   		Session::flash('success', 'Your Todo Was Created.');

   		return redirect()->back();

   }



   public function delete($id)
   {

   		$todo = todoModel::find($id);

   		$todo->delete();

   		Session::flash('success', 'Your Todo Was Deleted.');

   		return  redirect()->back();
   }


   public function update($id)
   {
	
		$todo = todoModel::find($id);

		return view('updateTodo')->with('todos', $todo);

   }

    public function save(Request $request, $id)
   {
   		// dd($request->all());

   		$todoObj = todoModel::find($id);

   		$todoObj->todo = $request->todo;

   		$todoObj->save();

   		Session::flash('success', 'Your Todo Was Updated.');

   		return redirect()->route('myTodos');

   }


   public function completed($id)
   {

   		$todoObj = todoModel::find($id);

   		$todoObj->completed = 1;

   		$todoObj->save();

   		Session::flash('success', 'Your Todo Was Marked as Completed.');

   		return redirect()->back();




   }
}
