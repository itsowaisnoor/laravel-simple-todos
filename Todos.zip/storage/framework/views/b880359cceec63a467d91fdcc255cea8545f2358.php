<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

       <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 24px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <div class="content">
                <div class="title m-b-md">
                	<?php if(Session::has('success')): ?>
	                	<div class="alert alert-success">
	                		 <?php echo e(Session::get('success')); ?>

						</div>
					<?php endif; ?>
                	<div class="row">
                		 <div class="col-lg-6 col-lg-offset-3">
                		<form action="/create/todo" method="post">
                			<?php echo e(csrf_field()); ?>

                			<input type="text" name="todo" placeholder=" create a new todo">
                		</form>
                		 </div>
                	</div>
 <hr>
<?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo e($todo->todo); ?> 
<a href="<?php echo e(route('todo.delete', ['id' => $todo->id ])); ?>" class="button btn-danger btn-xs">delete</a>
<a href="<?php echo e(route('todo.update', ['id' => $todo->id ])); ?>" class="button btn-info btn-xs">update</a>
<?php if(!$todo->completed): ?>

<a href="<?php echo e(route('todo.completed', ['id' => $todo->id])); ?>" class="button btn-success btn-xs"> Mark as completed </a>
<?php else: ?>

<span class="text-success"> Completed!</span>
<?php endif; ?>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </body>
</html>
